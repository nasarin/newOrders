package com.mohsinkd786.dtos;

import lombok.Data;

@Data
public class AddressDto {
    private String street;
    private String city;
    private String zipCode;
}
