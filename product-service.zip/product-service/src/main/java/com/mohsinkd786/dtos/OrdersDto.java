package com.mohsinkd786.dtos;

import lombok.Data;
@Data
public class OrdersDto {

    private String orderNo;
        private String street;
        private String city;
        private String zipCode;
}
